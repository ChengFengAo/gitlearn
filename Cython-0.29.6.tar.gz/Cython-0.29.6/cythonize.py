#!/usr/bin/env python

#
#   Cython -- enhanced main program
#

if __name__ == '__main__':
    from Cython.Build.Cythonize import main
    main()
